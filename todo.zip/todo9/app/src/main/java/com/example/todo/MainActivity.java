package com.example.todo;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Task> tasks;
    private TaskAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tasks = new ArrayList<>();
        ListView taskList = findViewById(R.id.taskList);
        adapter = new TaskAdapter(this, tasks);
        taskList.setAdapter(adapter);

        FloatingActionButton addTaskFab = findViewById(R.id.addTaskFab);
        addTaskFab.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Add New Task");

            final EditText input = new EditText(this);
            input.setHint("Enter task");
            builder.setView(input);

            builder.setPositiveButton("Add", (dialog, which) -> {
                String taskName = input.getText().toString();
                if (!taskName.isEmpty()) {
                    tasks.add(new Task(taskName)); // Add task with current date
                    adapter.notifyDataSetChanged(); // Refresh the list
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }
}
