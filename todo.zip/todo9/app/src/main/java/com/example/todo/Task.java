package com.example.todo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Task {
    private String name;
    private String dateModified;

    public Task(String name) {
        this.name = name;
        this.dateModified = getCurrentDateTime();
    }

    public String getName() {
        return name;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setName(String name) {
        this.name = name;
        this.dateModified = getCurrentDateTime(); // Update date modified when task changes
    }

    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }
}
